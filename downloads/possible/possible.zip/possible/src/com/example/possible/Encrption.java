package com.example.possible;

/**
 * Created by gjm1993 on 2016/9/22.
 */

import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;

public class Encrption {
    private static final String HEX = "0123456789ABCDEF";

    public Encrption() {
        super();
    }

    private static void appendHex(StringBuffer stringBuffer, byte b) {
        stringBuffer.append("0123456789ABCDEF".charAt(b >> 4 & 15)).append("0123456789ABCDEF".charAt(
                b & 15));
    }

    public static String decrypt(String key, String encrypted) throws Exception {
        return new String(Encrption.decrypt(Encrption.getRawKey(key.getBytes()), Encrption.toByte(encrypted)));
    }

    private static byte[] decrypt(byte[] raw, byte[] encrypted) throws Exception {
        SecretKeySpec v2 = new SecretKeySpec(raw, "AES");
        Cipher v0 = Cipher.getInstance("AES");
        v0.init(Cipher.DECRYPT_MODE, v2);
        return v0.doFinal(encrypted);
    }

    public static String encrypt(String key, String raw_text) throws Exception {
        return Encrption.toHex(Encrption.encrypt(Encrption.getRawKey(key.getBytes()), raw_text.getBytes()));
    }

    private static byte[] encrypt(byte[] raw, byte[] raw_text) throws Exception {
        SecretKeySpec v2 = new SecretKeySpec(raw, "AES");
        Cipher v0 = Cipher.getInstance("AES");
        v0.init(1, v2);
        return v0.doFinal(raw_text);
    }

    public static String fromHex(String hex) {
        return new String(Encrption.toByte(hex));
    }

    private static byte[] getRawKey(byte[] seed) throws Exception {
        KeyGenerator v0 = KeyGenerator.getInstance("AES");
        SecureRandom v3 = SecureRandom.getInstance("SHA1PRNG", "Crypto");
        //SecureRandom v3 = SecureRandom.getInstance("SHA1PRNG");
        v3.setSeed(seed);
        v0.init(128, v3);
        return v0.generateKey().getEncoded();
    }

    public static byte[] toByte(String hexString) {
        int v1 = hexString.length() / 2;
        byte[] v2 = new byte[v1];
        int v0;
        for (v0 = 0; v0 < v1; ++v0) {
            v2[v0] = Integer.valueOf(hexString.substring(v0 * 2, v0 * 2 + 2), 16).byteValue();
        }

        return v2;
    }

    public static String toHex(byte[] buf) {
        String v2;
        if (buf == null) {
            v2 = "";
        } else {
            StringBuffer v1 = new StringBuffer(buf.length * 2);
            int v0;
            for (v0 = 0; v0 < buf.length; ++v0) {
                Encrption.appendHex(v1, buf[v0]);
            }

            v2 = v1.toString();
        }

        return v2;
    }

    public static String toHex(String text) {
        return Encrption.toHex(text.getBytes());
    }
}


