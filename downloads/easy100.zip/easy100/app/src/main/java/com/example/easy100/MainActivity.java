package com.example.easy100;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;

public class MainActivity extends AppCompatActivity {

    private String url;
    private TextView tv;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = (TextView) this.findViewById(R.id.tv);
        readUrl();
        String key = this.a(url);
        a v2 = new a();
        v2.a(key.getBytes());
        String input = new String(v2.decrypt());
        tv.setText(input);
    }

    private void readUrl() {
        InputStream v0_1;
        try {
            v0_1 = this.getResources().getAssets().open("url.png");
            int v1 = v0_1.available();
            byte[] v2 = new byte[v1];
            v0_1.read(v2, 0, v1);
            byte[] v0_2 = new byte[16];
            System.arraycopy(v2, 144, v0_2, 0, 16);
            url = new String(v0_2, "utf-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String a(String url) {
        String v0_2;
        try {
            url.getBytes("utf-8");
            StringBuilder v1 = new StringBuilder();
            int v0_1;
            for (v0_1 = 0; v0_1 < url.length(); v0_1 += 2) {
                v1.append(url.charAt(v0_1 + 1));
                v1.append(url.charAt(v0_1));
            }

            v0_2 = v1.toString();
        } catch (UnsupportedEncodingException v0) {
            v0.printStackTrace();
            v0_2 = null;
        }

        return v0_2;
    }

}
