package com.example.easy100;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class a {
    private SecretKeySpec a;
    private Cipher b;
    private byte[] cipher = new byte[]{21, -93, -68, -94, 86, 117, -19, -68,
            -92, 33, 50, 118, 16, 13, 1, -15, -13, 3, 4, 103, -18, 81, 30, 68, 54, -93, 44, -23,
            93, 98, 5, 59};

    public a() {
        super();
    }

    protected void a(byte[] arg4) {
        try {
            this.a = new SecretKeySpec(arg4, "AES");
            this.b = Cipher.getInstance("AES/ECB/PKCS5Padding");
        } catch (Exception v0_2) {
            v0_2.printStackTrace();
        }
    }

    protected byte[] decrypt() {
        byte[] bytes = null;
        try {
            this.b.init(Cipher.DECRYPT_MODE, this.a);
            bytes = this.b.doFinal(cipher);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bytes;
    }

}

